var main = function(){
    var searchAPIKey = "0a37f1bc41faaf3db26da6005371e78c:15:71605180",
        searchKeyword = "Obama",
        beginDate = "20141201",
        endDate = "20150317",
        sort = "newest";
        
    $.getJSON("http://api.nytimes.com/svc/search/v2/articlesearch.json?             q="+searchKeyword+"&sort="+sort+"&begin_date="+beginDate+"&end_date="+endDate+"&callback=sv c_search_v2_articlesearch&api-key="+searchAPIKey, function (data) {
    
        var retrievedData = data.response.docs;
        //var $snippet = $("<li>");
        //var $newsList = $("<ul>");
    
        for (var i = 0; i < retrievedData.length; i++){
        console.log(retrievedData[i]);
        console.log(retrievedData[i].snippet);

        }
    });
};
$(document).ready(main);